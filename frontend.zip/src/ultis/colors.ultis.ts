const colors = {
    mainColor: "#103A49",
    backgroundColor: "#F3F3F3",
    iconColor: "#68878E",
    bannerColor: "#FF622D",
}

export default colors;
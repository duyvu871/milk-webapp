"use client"

import TrendingDisplay from "@/components/Trending";

export default function Page() {
    
    return (
        <div className={"flex flex-col justify-center items-center w-full"}>
            <TrendingDisplay/>
        </div>
    )
}
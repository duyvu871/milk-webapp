const AppConfig = {
    mainApiUrl: 'https://ha-nam-milk-backend-s1.onrender.com',
    // mainApiUrl: 'http://localhost:3002',
}

export default AppConfig;